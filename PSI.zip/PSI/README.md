# PSI
Projet informatique lié au traitement d'image au format bitmap
